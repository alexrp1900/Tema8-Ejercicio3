package T8Ejer3;

public class Directivo extends Empleado {
	
	private String nombre;

	public Directivo() {

	}

	public Directivo(String nombre) {

		this.nombre = nombre;

	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public String toString() {
		this.nombre=this.nombre+" es un objeto de la clase Empleado-- > Directivo";
		
		return this.nombre;
	}
	
}
