package T8Ejer3;

public class main {

	public static void main(String[] args) {
		
		Empleado E1 = new Empleado("Rafa");
		
		Directivo D1 = new Directivo("Mario");
		
		Operario OP1 = new Operario("Alfonso");
		
		Oficial OF1 = new Oficial("Luis");
		
		T�cnico T1 = new T�cnico("Jose Mar�a");
		
		System.out.println(E1);
		
		System.out.println(D1);
		
		System.out.println(OP1);
		
		System.out.println(OF1);
		
		System.out.println(T1);
		
	}

}
