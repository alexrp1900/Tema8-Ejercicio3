package T8Ejer3;

public class T�cnico extends Operario{

	private String nombre;

	public T�cnico() {

	}

	public T�cnico(String nombre) {

		this.nombre = nombre;

	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public String toString() {
		this.nombre=this.nombre+" es un objeto de la clase Empleado-- > Operario -- >T�cnico";
		
		return this.nombre;
	}
	
}
