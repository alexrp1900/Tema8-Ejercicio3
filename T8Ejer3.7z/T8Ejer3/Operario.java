package T8Ejer3;

public class Operario extends Empleado{

	private String nombre;

	public Operario() {

	}

	public Operario(String nombre) {

		this.nombre = nombre;

	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public String toString() {
		this.nombre=this.nombre+" es un objeto de la clase Empleado-- > Operario";
		
		return this.nombre;
	}
	
}
